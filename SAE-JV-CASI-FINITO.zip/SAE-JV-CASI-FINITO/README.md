# SAE-JV

Installation et Lancement Rapide
Prérequis :
- Assurez-vous d’avoir Python installé sur votre ordinateur.
  
BIBLIOTHEQUES :
- pygame 
- random 
- os 
- sys
- subprocess
- webbrowser
- tkinter.simpledialog

Téléchargement du ZIP :
- Téléchargez le ZIP à partir du lien du GIT.

Extraction des Fichiers :
- Extrayez le contenu de l’archive dans un dossier de votre choix.

Exécution du Jeu :
- Ouvrez un terminal ou une invite de commande. 
- Naviguez jusqu’au dossier où vous avez extrait les fichiers du jeu.
Exécutez le jeu en utilisant la commande suivante :python Main.py pour seulement jouer au jeu.
