import pygame
import socket
import threading
import sys

class CommunicationClient:
    def __init__(self, ip_address, port):
        self.ip_address = ip_address
        self.port = port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client_socket.connect((self.ip_address, self.port))

    def envoi_data(self, data):
        self.client_socket.sendall(data.encode())

    def recoit_data(self):
        data = self.client_socket.recv(1024)
        return data.decode()

    def ferme_connexion(self):
        self.client_socket.close()

def recevoir_server_data(client_communication):
    while True:
        cle_evenement = client_communication.recoit_data()
        maj_display(cle_evenement)

def maj_display(cle_evenement):
    print(f"Recevoir cle_evenement: {cle_evenement}")

def main():
    pygame.init()

    server_address = "127.0.0.1"
    server_port = 12345

    client = CommunicationClient(server_address, server_port)
    threading.Thread(target=recevoir_server_data, args=(client,)).start()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                cle_evenement = str(event.key)
                client.envoi_data(cle_evenement)

if __name__ == "__main__":
    main()